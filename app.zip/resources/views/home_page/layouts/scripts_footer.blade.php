 <!-- jQuery-2.2.4 js -->
 <script src="{{ asset('assets/home_page/') }}/js/jquery/jquery-2.2.4.min.js"></script>
 <!-- Popper js -->
 <script src="{{ asset('assets/home_page/') }}/js/bootstrap/popper.min.js"></script>
 <!-- Bootstrap js -->
 <script src="{{ asset('assets/home_page/') }}/js/bootstrap/bootstrap.min.js"></script>
 <!-- All Plugins js -->
 <script src="{{ asset('assets/home_page/') }}/js/plugins/plugins.js"></script>
 <!-- Active js -->
 <script src="{{ asset('assets/home_page/') }}/js/active.js"></script>
