<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

class TypeEventController extends Controller
{
    //
}
