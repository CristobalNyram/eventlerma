<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

class TypePublicController extends Controller
{
    protected $table = 'type_public'; // Nombre de tu tabla en la base de datos

}
