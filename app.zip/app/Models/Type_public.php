<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class Type_public extends Model
{
    use HasFactory;
    protected $table = 'type_public'; // Nombre de tu tabla en la base de datos

}
